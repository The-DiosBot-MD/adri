How to install the Basic theme:

Go to the folder: /var/www/ctrlpanel/.

Copy the two folders (located in the same folder as this guide) into /var/www/ctrlpanel/.

Open your CtrlPanel in the browser.

Go to Settings > General.

Scroll down and change the theme to Basic.

Perform a hard refresh of the page by pressing Ctrl + Shift + R.


If you encounter any problems, please contact NolDys on Discord.