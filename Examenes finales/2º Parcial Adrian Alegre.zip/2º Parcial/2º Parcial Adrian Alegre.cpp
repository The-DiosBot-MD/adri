#include <iostream>
#include <string>
#include <iomanip> 
#include <ctime>  
using namespace std;
int main() {
    int N; 
    cout << "Ingrese la cantidad de alumnos: ";
    cin >> N;
    string* NOM = new string[N];     
    int* ANAC = new int[N];          
    float* PRIM = new float[N];      
    float* SEG = new float[N];      
    float* TER = new float[N];      
    int* EDAD = new int[N];          
    float* PROMEDIO = new float[N];  
    int yearActual;
    time_t t = time(0);
    tm* now = localtime(&t);
    yearActual = now->tm_year + 1900; 
    cout << "=== Registro de Alumnos de la Promoci�n 2024 ===\n";
    for (int i = 0; i < N; i++) {
        cout << "\nAlumno #" << i + 1 << ":\n";
        cout << "Ingrese el Nombre: ";
        cin >> NOM[i];
        cout << "Ingrese el a�o de nacimiento: ";
        cin >> ANAC[i];
        while (ANAC[i] < 1900 || ANAC[i] > yearActual) {
            cout << "A�o inv�lido. Intente nuevamente: ";
            cin >> ANAC[i];
        }
        
        cout << "Promedio 1� curso (1-5): ";
        cin >> PRIM[i];
        while (PRIM[i] < 1 || PRIM[i] > 5) {
            cout << "Promedio inv�lido. Intente nuevamente: ";
            cin >> PRIM[i];
        }

        cout << "Promedio 2� curso (1-5): ";
        cin >> SEG[i];
        while (SEG[i] < 1 || SEG[i] > 5) {
            cout << "Promedio inv�lido. Intente nuevamente: ";
            cin >> SEG[i];
        }

        cout << "Promedio 3� curso (1-5): ";
        cin >> TER[i];
        while (TER[i] < 1 || TER[i] > 5) {
            cout << "Promedio inv�lido. Intente nuevamente: ";
            cin >> TER[i];
        }

        EDAD[i] = yearActual - ANAC[i];

        PROMEDIO[i] = (PRIM[i] + SEG[i] + TER[i]) / 3.0;
    }

    float mediaGeneral = 0;
    for (int i = 0; i < N; i++) {
        mediaGeneral += PROMEDIO[i];
    }
    mediaGeneral /= N;

    cout << "\n=== Resultados de los Alumnos ===\n";
    for (int i = 0; i < N; i++) {
        cout << NOM[i] << " - Edad: " << EDAD[i]
             << " - 1� curso: " << PRIM[i]
             << ", 2� curso: " << SEG[i]
             << ", 3� curso: " << TER[i]
             << " - Promedio general: " << fixed << setprecision(1) << PROMEDIO[i];
        if (PROMEDIO[i] > 4.3) {
            cout << " (Mejor Alumno)";
        }
        cout << endl;
    }

    cout << "\nAlumnos con promedio mayor a la media (" << fixed << setprecision(1) << mediaGeneral << "):\n";
    for (int i = 0; i < N; i++) {
        if (PROMEDIO[i] > mediaGeneral) {
            cout << NOM[i] << " - Promedio general: " << PROMEDIO[i] << endl;
        }
    }

    cout << "\nAlumnos con promedio 2 o menor:\n";
    for (int i = 0; i < N; i++) {
        if (PROMEDIO[i] <= 2) {
            cout << NOM[i] << " - Promedio general: " << PROMEDIO[i] << endl;
        }
    }

    for (int i = 0; i < N; i++) {
        NOM[i] = "";
        ANAC[i] = 0;
        PRIM[i] = SEG[i] = TER[i] = 0.0f;
        EDAD[i] = 0;
        PROMEDIO[i] = 0.0f;
    }

    return 0;
}

